async function generateChallenge() {

    // 🔑 Mets ici ta clé API OpenRouter
    const apiKey = "";

    const type = document.getElementById('question').value;
    const level = document.getElementById('level').value;

    const textElement = document.getElementById('text');
    const loader = document.getElementById('loader');

    textElement.innerText = "";
    loader.style.display = "block";

    // Prompt ultra-agressif pour des défis plus créatifs
    const prompt = `
        Tu es une IA spécialisée dans les mathématiques de lycée.

        Génère une éxplication claire concernant le "${question}" 
        pour un niveau "${level}".

        Règles :
        - Explication détaillé
        - Très clair
        - Pas de commentaire
        - Pas d'introduction
        - Pas de guillemets
        - Réponds uniquement en français
        `;

    try {

        const response = await fetch(
            "https://openrouter.ai/api/v1/chat/completions",
            {
                method: "POST",

                headers: {
                    "Content-Type": "application/json",

                    // API KEY
                    "Authorization": `Bearer ${apiKey}`,

                    // Obligatoire pour OpenRouter
                    "HTTP-Referer": "http://localhost:8000",
                    "X-Title": "IA Challenge"
                },

                body: JSON.stringify({

                    // 🔥 Dolphin Mixtral
                    model: "cognitivecomputations/dolphin-mixtral-8x7b",

                    messages: [
                        {
                            role: "system",
                            content: `
                                Tu es une IA de prof de Math.
                                Tu dois générer des explications claires
                                qui s'adapte aux terminale.
                                `
                        },
                        {
                            role: "user",
                            content: prompt
                        }
                    ],

                    temperature: 1.2,
                    max_tokens: 120,
                    top_p: 0.95
                })
            }
        );

        // Récupération JSON
        const data = await response.json();

        console.log(data);

        // Gestion erreurs API
        if (!response.ok) {

            throw new Error(
                data.error?.message ||
                "Erreur API OpenRouter"
            );
        }

        // Affichage réponse IA
        textElement.innerText =
            data.choices[0].message.content.trim();

    } catch (error) {

        console.error(error);

        textElement.innerText =
            "Erreur IA : " + error.message;

    } finally {

        loader.style.display = "none";
    }
}
const btn = document.getElementById('btn');
btn.addEventListener('click', generateChallenge())